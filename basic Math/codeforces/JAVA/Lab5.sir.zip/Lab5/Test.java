public class Test {
    public static void main(String[] args) {
        Main m = new Main();
        Main n = new Main();
        System.out.println(m.getN());
        System.out.println(n.getN());
        Icecream I1 = new Icecream();
        Icecream I2 = new Icecream();
        System.out.println(I1.getN());
        System.out.println(I2.getN());
        System.out.println(I2.getN());
    }
}
